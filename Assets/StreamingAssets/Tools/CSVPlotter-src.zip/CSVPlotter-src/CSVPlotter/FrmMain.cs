﻿using System;
using System.IO;
using System.Windows.Forms;
using Ibit.Core.Util;

namespace ChartCSVBuilder
{
    public partial class Graph : Form
    {
        private string[] _args;

        public Graph(string[] args)
        {
            _args = args;
            InitializeComponent();
        }

        private void OpenFile(string path)
        {
            var file = new FileInfo(path);
            var data = File.ReadAllLines(file.FullName);

            for (var i = 1; i < data.Length; i++)
            {
                var split = data[i].Split(';');
                var time = double.Parse(split[0]);
                var value = FlowMath.ToLitresPerMinute(double.Parse(split[1]));
                chart1.Series["Series1"].Points.AddXY(time, value);
            }

            chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = true;
            chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;

            this.Text = file.Name;
        }

        private void Graph_Shown(object sender, EventArgs e)
        {
            if (_args.Length > 0)
                OpenFile(_args[0]);
            else
            {
                var dialog = new OpenFileDialog();
                dialog.Filter = "Comma Separeted Value (*.csv)|*.csv";
                var result = dialog.ShowDialog();

                if (dialog.FileName.Length < 1 || result == DialogResult.Cancel)
                    Environment.Exit(0);

                OpenFile(dialog.FileName);
            }
        }
    }
}
