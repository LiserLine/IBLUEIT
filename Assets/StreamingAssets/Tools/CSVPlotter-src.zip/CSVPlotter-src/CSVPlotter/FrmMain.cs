﻿using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace ChartCSVBuilder
{
    public partial class Graph : Form
    {
        public Graph(string[] args)
        {
            InitializeComponent();

            if (args.Length < 1)
                return;

            var file = new FileInfo(args[0]);
            var data = File.ReadAllLines(file.FullName);

            for (var i = 1; i < data.Length; i++)
            {
                var split = data[i].Split(';');
                chart1.Series["Series1"].Points.AddXY(double.Parse(split[0]), double.Parse(split[1].Replace(',', '.'), CultureInfo.InvariantCulture));

            }

            this.Text = file.Name;
        }
    }
}
