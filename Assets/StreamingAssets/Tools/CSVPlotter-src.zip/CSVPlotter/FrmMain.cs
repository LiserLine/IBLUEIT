﻿using System;
using System.IO;
using System.Windows.Forms;
using Ibit.Core.Util;

namespace ChartCSVBuilder
{
    public partial class Graph : Form
    {
        private string[] _args;

        public Graph(string[] args)
        {
            _args = args;
            InitializeComponent();
        }

        private void OpenFile(string path)
        {
            var file = new FileInfo(path);
            var data = File.ReadAllLines(file.FullName);

            for (var i = 1; i < data.Length; i++)
            {
                var split = data[i].Split(';');
                var time = double.Parse(split[0]);
                var value = FlowMath.ToLitresPerMinute(double.Parse(split[1]));
                time = Math.Round(time,3);
                chart1.Series[0].Points.AddXY(time, value);
            }

            chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
            chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = true;

            chart1.ChartAreas[0].AxisX.LabelStyle.Angle = -90;
            chart1.ChartAreas[0].AxisX.LabelStyle.Interval = 1;

            if(chart1.Series[0].Points.Count > 1500)
             chart1.ChartAreas[0].AxisX.LabelStyle.Interval = 5;

            this.Text = file.Name;
        }

        private void Graph_Shown(object sender, EventArgs e)
        {
            if (_args.Length > 0)
                OpenFile(_args[0]);
            else
            {
                var dialog = new OpenFileDialog();
                dialog.Filter = "Comma Separeted Value (*.csv)|*.csv";
                var result = dialog.ShowDialog();

                if (dialog.FileName.Length < 1 || result == DialogResult.Cancel)
                    Environment.Exit(0);

                OpenFile(dialog.FileName);
            }
        }

        private void Graph_ResizeEnd(object sender, EventArgs e)
        {
            chart1.Update();
        }
    }
}
