﻿using System;

namespace Ibit.Core.Util
{
    public class FlowMath
    {
        /// <summary>
        /// Converts m³/s to L/min
        /// </summary>
        private const double LitresPerMinuteConverter = 60000;

        /* Pitaco Measures */
        private const double tubeRadius = 0.018;
        private const double tubeLenght = 0.2;
        private const double airViscosity = 18.2 * 0.000001;

        /// <summary>
        /// Returns the volumetric flow of air in Cubic Meter / Second
        /// </summary>
        /// <param name="differentialPressure">Pressure difference in Pascal (Pa)</param>
        /// <returns></returns>
        private static double Poiseulle(double differentialPressure) =>
            differentialPressure * Math.PI * Math.Pow(tubeRadius, 4) / (8 * airViscosity * tubeLenght);

        /// <summary>
        /// Returns the volumetric flow of air in Litres/Minute
        /// </summary>
        /// <param name="differentialPressure">Pressure difference in Pascal (Pa)</param>
        /// <returns></returns>
        public static double ToLitresPerMinute(double differentialPressure) => Poiseulle(differentialPressure / 1000) * LitresPerMinuteConverter;
    }
}