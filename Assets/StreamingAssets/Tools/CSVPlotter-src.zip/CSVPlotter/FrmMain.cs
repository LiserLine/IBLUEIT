﻿using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace ChartCSVBuilder
{
    public partial class Graph : Form
    {
        public Graph(string[] args)
        {
            InitializeComponent();

            if (args.Length > 0)
                OpenFile(args[0]);
            else
            {
                var dialog = new OpenFileDialog();
                dialog.Filter = "Comma Separeted Value (*.csv)|*.csv";
                var result = dialog.ShowDialog();

                if (dialog.FileName.Length < 1)
                    return;

                OpenFile(dialog.FileName);
            }
        }

        private void OpenFile(string path)
        {
            var file = new FileInfo(path);
            var data = File.ReadAllLines(file.FullName);

            for (var i = 1; i < data.Length; i++)
            {
                var split = data[i].Split(';');
                chart1.Series["Series1"].Points.AddXY(double.Parse(split[0]), double.Parse(split[1].Replace(',', '.'), CultureInfo.InvariantCulture));
            }

            this.Text = file.Name;
        }
    }
}
