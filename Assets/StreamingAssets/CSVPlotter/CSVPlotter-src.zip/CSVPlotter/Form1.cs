﻿using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace ChartCSVBuilder
{
	public partial class Graph : Form
	{
		public Graph(string[] args)
		{
			InitializeComponent();
			if (args.Length < 1) return;
			var file = new FileInfo(args[0]);
			var data = File.ReadAllLines(file.FullName);

			foreach (var t in data)
			{
				var split = t.Split(';');
				chart1.Series["Series1"].Points.AddXY(double.Parse(split[0]), double.Parse(split[1].Replace(',', '.'), CultureInfo.InvariantCulture));
			}

			this.Text = file.Name;
		}
	}
}
